export class GalleryImageElement {
  id: string;
  src: string;
  previewUrl: string;
  caption: string;
}