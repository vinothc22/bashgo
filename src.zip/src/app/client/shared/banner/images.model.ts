export interface ImageElement {
    id: string;
    url: string;
    caption: string;
}