export interface ClientElements {
    id: string;
    src: string;
    caption: string

}