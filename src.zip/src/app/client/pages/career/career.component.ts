import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'bashgo-career',
  templateUrl: './career.component.html',
  styleUrls: ['./career.component.scss']
})
export class CareerComponent implements OnInit {

  bannerImage: string = 'career-image.jpg';
  applyForm: FormGroup;
  submitted: boolean = false;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.applyForm = this.formBuilder.group({
      name: ['', Validators.required],
      contactNo: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      location: ['', Validators.required],
      jobCode: ['', Validators.required],
      resume: ['', Validators.required],
    });
  }

  get f() {
    return this.applyForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    if (this.applyForm.invalid) {
      return;
    }
    console.log(JSON.stringify(this.applyForm.value, null, 4))

  }

}
