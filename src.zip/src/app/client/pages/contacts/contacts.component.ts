import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormService } from '../../shared/services/form-service.service';

@Component({
  selector: 'bashgo-contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.scss']
})
export class ContactsComponent implements OnInit {

  bannerImage: string = 'contacts-image.jpg';

  contactForm: FormGroup;
  submitted: boolean = false;

  constructor(private formBuilder: FormBuilder, private contact: FormService) { }

  ngOnInit(): void {
    this.contactForm = this.formBuilder.group({
      name: ['', Validators.required],
      designation: ['', Validators.required],
      company: ['', Validators.required],
      industry: [''],
      contactNo: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      country: ['', Validators.required],
      contents: ['', Validators.required],
    });
  }

  get f() {
    return this.contactForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    if (this.contactForm.invalid) {
      return;
    }
    this.contact.postContactMessage(this.contactForm.value)
      .subscribe(response => {
        console.log(response);
      }, error => {
        console.warn(error.responseText);
        console.log({ error });
      });
    console.log(JSON.stringify(this.contactForm.value, null, 4))
  }

  onClear() {
    this.submitted = false;
    this.contactForm.reset();
  }

}
