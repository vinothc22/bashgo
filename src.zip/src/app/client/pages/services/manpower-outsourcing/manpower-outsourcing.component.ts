import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bashgo-manpower-outsourcing',
  templateUrl: './manpower-outsourcing.component.html',
  styleUrls: ['./manpower-outsourcing.component.scss']
})
export class ManpowerOutsourcingComponent implements OnInit {

  bannerImage: any = 'manpower-outsourcing.jpg';

  constructor() { }

  ngOnInit(): void {
  }

}
